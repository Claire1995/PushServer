﻿const json = {
    "notification": { "title": "Push alarm", "body": "Have a nice day!" },
    "to": "cjwzf3CgP70:APA91bF-l4YJziCEYyy3WLL5Jy3K7vGbdoqcgp9MVynBEc8Mabq305YLmk_2YrCiMX5nraLydSVI-QJNJ1y3FNZCYg9gSmgXjQ5PN_xgoXUtdHTVsQeaPv4aQOtbbJt-varMQi-pdEvT"
}

function processEvent() {
    const httpRequest = new XMLHttpRequest();
    httpRequest.open("POST", "https://fcm.googleapis.com/fcm/send", true);
    httpRequest.setRequestHeader('Content-Type', 'application/json');
    httpRequest.setRequestHeader('Authorization', 'key=' + 'AAAAmZPXGT4:APA91bHlFAOJdlb6f5NTnYHzFxXUiPqXR_JcxrHSp0lxlqubMtLsr8XbULN8zSAxLp59ay79bhLJfepzezJCM2YXU23PKIEuYpIfHsslqoDBDEzy_drYKfjiS11FVaTyDDuuRGQB8_eT');

    httpRequest.onreadystatechange = function () {
        if (httpRequest.status == 200 && httpRequest.readyState == 4) {
            console.log(httpRequest.responseText);

        } else {
            console.log('error');

        }
    }
    httpRequest.send(JSON.stringify(json));
}
processEvent();